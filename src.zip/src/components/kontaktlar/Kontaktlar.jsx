import React from 'react'
import './Kontaktlar.css'

function Kontaktlar() {
  return (
    <div>
      
    </div>
  )
}

export default Kontaktlar
