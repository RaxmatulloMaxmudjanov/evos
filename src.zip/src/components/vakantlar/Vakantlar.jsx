import React from 'react'
import './Vakantlar.css'

function Vakantlar() {
  return (
    <div>
      
    </div>
  )
}

export default Vakantlar
