import React from 'react'
import './Yetgazish.css'

function Yetgazish() {
  return (
    <div className='yetgazish'>
      {/* <h1>yetgazish</h1> */}
    </div>
  )
}

export default Yetgazish
