import React from 'react'
import './Filiallar.css'

function Filiallar() {
  return (
    <div className='filiallar'>
      <h1>Filialllar</h1>
    </div>
  )
}

export default Filiallar
