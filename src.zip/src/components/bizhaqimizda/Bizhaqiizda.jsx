import React from 'react'
import './Bizhaqiizda'

function Bizhaqiizda() {
  return (
    <div>
      
    </div>
  )
}

export default Bizhaqiizda
