import React from 'react'
import './Yangiliklar.css'

function Yangiliklar() {
  return (
    <div>
      
    </div>
  )
}

export default Yangiliklar
